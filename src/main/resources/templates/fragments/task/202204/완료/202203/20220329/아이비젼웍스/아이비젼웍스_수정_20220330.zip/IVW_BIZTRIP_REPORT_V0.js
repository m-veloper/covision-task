//양식별 다국어 정의 부분
var localLang_ko = {
    localLangItems: {
    }
};

var localLang_en = {
    localLangItems: {
    }
};

var localLang_ja = {
    localLangItems: {
    }
};

var localLang_zh = {
    localLangItems: {
    }
};


//양식별 후처리를 위한 필수 함수 - 삭제 시 오류 발생
function postRenderingForTemplate() {
    // 체크박스, radio 등 공통 후처리
    postJobForDynamicCtrl();

    //읽기 모드 일 경우
    if (getInfo("Request.templatemode") == "Read") {

        $('*[data-mode="writeOnly"]').each(function () {
            $(this).hide();
        });
        
        //<!--loadMultiRow_Read-->
        if (JSON.stringify(formJson.BodyContext) != "{}" && formJson.BodyContext != undefined) {
            XFORM.multirow.load(JSON.stringify(formJson.BodyContext.tbl_info), 'json', '#tbl_info', 'R');
        }
    }
    else {
        $('*[data-mode="readOnly"]').each(function () {
            $(this).hide();
        });

        // 에디터 처리
        //<!--AddWebEditor-->
        
        if (formJson.Request.mode == "DRAFT" || formJson.Request.mode == "TEMPSAVE") {

            document.getElementById("InitiatorOUDisplay").value = m_oFormMenu.getLngLabel(getInfo("AppInfo.dpnm"), false);
            document.getElementById("InitiatorDisplay").value = m_oFormMenu.getLngLabel(getInfo("AppInfo.usnm"), false);
        }
     
        //<!--loadMultiRow_Write-->
        if (JSON.stringify(formJson.BodyContext) != "{}" && JSON.stringify(formJson.BodyContext) != undefined) {
            XFORM.multirow.load(JSON.stringify(formJson.BodyContext.tbl_info), 'json', '#tbl_info', 'W');
        } else {
            XFORM.multirow.load('', 'json', '#tbl_info', 'W', { minLength: 1 });
        }
    }
}

function setLabel() {
}

function setFormInfoDraft() {
}

function checkForm(bTempSave) {
    if (bTempSave) {
        return true;
    } else {
        // 필수 입력 필드 체크
        return EASY.check().result;
    }
}

function setBodyContext(sBodyContext) {
}

//본문 XML로 구성
function makeBodyContext() {
	var bodyContextObj = {};
	bodyContextObj["BodyContext"] = getFields("mField");
	$$(bodyContextObj["BodyContext"]).append(getMultiRowFields("tbl_info", "rField"));
	
    return bodyContextObj;
}

function calTotDays(obj) {
	
	var objtr = $(obj).closest("tr");
	if($(objtr).find("input[name=SDate]").val() != "" && $(objtr).find("input[name=EDate]").val() != ""){
		var sDate = parseInt($(objtr).find("input[name=SDate]").val().replace(/[^0-9]/g, ''));
		var eDate = parseInt($(objtr).find("input[name=EDate]").val().replace(/[^0-9]/g, ''));
		
		var subDate = eDate - sDate;
		
		$(objtr).find("input[name=TotDays]").val(subDate+1);
		EASY.triggerFormChanged();
		
        if(subDate < 0){ // 시작일 > 종료일
        	alert("이전 일보다 전 입니다. 확인하여 주십시오.");
        	$(objtr).find("input[name=SDate]").val("");
        	$(objtr).find("input[name=EDate]").val("");
        	$(objtr).find("input[name=TotDays]").val("");
        } else if(subDate == 0){ // 시작일 == 종료일 -> 시간체크 필요
        	
        	if($(objtr).find("input[name=STime]").val() != "" && $(objtr).find("input[name=ETime]").val() != ""){
        		var sTime = parseInt($(objtr).find("input[name=STime]").val().replace(/[^0-9]/g, ''));
        		var eTime = parseInt($(objtr).find("input[name=ETime]").val().replace(/[^0-9]/g, ''));
        		var subTime = sTime - eTime;
        		if(subTime > 0){
        			alert("이전 일보다 전 입니다. 확인하여 주십시오.");
        			$(objtr).find("input[name=STime]").val("");
                	$(objtr).find("input[name=ETime]").val("");
        		}
        	}
        }
	}
}

function allMoney1(obj){
		
	var dispatchPAY = toNum($(obj).parent().parent().find("input[name=dispatchPAY]"));
	var dispatchPAYCom = toNum($(obj).parent().parent().find("input[name=dispatchPAYCom]"));
	var preDispatchPAY = toNum($(obj).parent().parent().parent().find("input[name=preDispatchPAY]"));
	var preDispatchPAYCom = toNum($(obj).parent().parent().parent().find("input[name=preDispatchPAYCom]"));
	console.log("dispatchPAY : "+dispatchPAY);
	console.log("dispatchPAYCom : "+dispatchPAYCom);
	console.log("preDispatchPAY : "+preDispatchPAY);
	console.log("preDispatchPAYCom : "+preDispatchPAYCom);
	
	var dispatchPAYPrice =0;
	var preDispatchPAYPrice =0;
	dispatchPAYPrice = dispatchPAY-preDispatchPAY;
	preDispatchPAYPrice = dispatchPAYCom-preDispatchPAYCom;
	$(obj).parent().parent().parent().find("input[name=calculationPAY]").val(dispatchPAYPrice);
	$(obj).parent().parent().parent().find("input[name=calculationPAYCom]").val(preDispatchPAYPrice);
}

function allMoney2(obj){
	
	var dispatchPAY = toNum($(obj).parent().parent().parent().find("input[name=dispatchPAY]"));
	var dispatchPAYCom = toNum($(obj).parent().parent().parent().find("input[name=dispatchPAYCom]"));
	var preDispatchPAY = toNum($(obj).parent().parent().find("input[name=preDispatchPAY]"));
	var preDispatchPAYCom = toNum($(obj).parent().parent().find("input[name=preDispatchPAYCom]"));
	
	
	dispatchPAYPrice = dispatchPAY-preDispatchPAY;
	preDispatchPAYPrice = dispatchPAYCom-preDispatchPAYCom;
	$(obj).parent().parent().parent().find("input[name=calculationPAY]").val(dispatchPAYPrice);
	$(obj).parent().parent().parent().find("input[name=calculationPAYCom]").val(preDispatchPAYPrice);
}
function toNum(obj){
	return Number($(obj).val().toString().replace(/\,/gi, ''));
} 